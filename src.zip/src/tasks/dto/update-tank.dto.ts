import { CreateTaskDto } from "./create-tank.dto";
import { PartialType } from "@nestjs/mapped-types";
import { TaskStatus } from "../task.model";
import { IsEnum } from "class-validator";

export class UpdateTaskDto extends PartialType(CreateTaskDto) {
@IsEnum(TaskStatus, { message: 'Lo status deve essere OPEN, IN_PROGRESS o DONE' })
   status?:TaskStatus
}